# Dockit Astro

#### Preview

 - [Demo](https://themewagon.github.io/dockit/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/dockit/)

## Getting Started

1. Clone Repository
```
git clone https://github.com/themewagon/dockit.git
```
2. Install Dependencies
```
npm i
```
3. Run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

## Author 
```
Design and code is completely written by Themefisher and development team. 
```

## License

 - Design and Code is Copyright &copy; <a href="https://themefisher.com/" target="_blank">Themefisher</a>
 - Licensed cover under [MIT]
 - Distributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a>
